import requests
import time
import os
from dotenv import load_dotenv
import json
import logging
import sys
import pandas as pd
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from utils import utils

config = utils.config_reader()
logger = utils.log_formatter()

logger.info('Teste logger')
logger.info('Subindo variáveis do .ENV')

files_path = config['azure']['file_path']

load_dotenv()
SUBSCRIPTION_KEY = os.getenv('SUBSCRIPTION_KEY')
AUTH_TOKEN = os.getenv('AUTH_TOKEN')
MODELID = config['azure']['modelId']
ENDPOINT = str(config['azure']['endpoint']).replace('{modelId}', MODELID)


def azBlobUpload(inputItems: list) -> list:
    from azure.storage.blob import BlobServiceClient

    storage_connection_string = inputItems[1]
    blob_service_client = BlobServiceClient.from_connection_string(storage_connection_string)

    list_blobUrls = []
    files_path = inputItems[0]
    for file_name in os.listdir(files_path):
        print(f'DOC: {file_name}')
        blob_obj = blob_service_client.get_blob_client(container='desenvolvimento', blob=file_name)

        if file_name.endswith(".pdf"):
            file_data = os.path.join(files_path, file_name)
        else:
            continue

        with open(file_data, 'rb') as data:
            print(f'Uploading: {file_data}')
            blob_obj.upload_blob(data, overwrite=True)
        list_blobUrls.append((blob_obj.url, file_name))

    return list_blobUrls


def call_model(subscription_key, endpoint, document_url, file_name) -> dict:
    headers = {
        "Content-Type": "application/json",
        "Ocp-Apim-Subscription-Key": subscription_key,
    }

    data = {
        "urlSource": document_url
    }

    response = requests.post(endpoint, headers=headers, json=data)

    if response.status_code == 202:
        operation_url = response.headers["Operation-Location"]
        while True:
            response = requests.get(operation_url, headers=headers)
            status = response.json()['status']
            print(f"Status da análise: {status}")

            if status == 'succeeded':
                break
            elif status == 'failed':
                print("A análise falhou.")
                return {}
            else:
                time.sleep(5)

        if response.status_code == 200:
            result_json = response.json()
            fields = result_json['analyzeResult']['documents'][0]['fields']

            parecer_apto = fields.get('parecer_apto', {}).get('content', 'Parecer não encontrado.')
            crm_examinador = fields.get('crm_medico', {}).get('content', 'CRM Examinador não encontrado.')
            parecer_inapto = fields.get('parecer_inapto', {}).get('content', 'Parecer não encontrado.')
            nome_paciente = fields.get('nome_paciente', {}).get('content', 'Nome paciente não encontrado.')

            return {
                'nome_paciente': nome_paciente,
                'crm_examinador': crm_examinador,
                'parecer_apto': 'X' if 'X' in parecer_apto else 'N/A',
                'parecer_inapto': 'X' if 'X' in parecer_inapto else 'N/A',
                'data_extracao': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'arquivo': file_name,
                'url_documento': document_url
            }

    else:
        print("Erro na requisição:", response.text)
        return {}


def gerar_excel(dados: list, caminho_saida: str = 'output_azure_model.xlsx'):
    df = pd.DataFrame(dados)
    df.to_excel(caminho_saida, index=False)
    print(f"Arquivo Excel gerado com sucesso em: {caminho_saida}")


# EXECUÇÃO
blob_url_list = azBlobUpload([files_path, AUTH_TOKEN])
dados_extraidos = []

for doc_url, file_name in blob_url_list:
    resultado = call_model(subscription_key=SUBSCRIPTION_KEY, endpoint=ENDPOINT, document_url=doc_url, file_name=file_name)
    if resultado:
        dados_extraidos.append(resultado)

if dados_extraidos:
    gerar_excel(dados_extraidos)